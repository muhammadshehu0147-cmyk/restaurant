# Quick Pay Pro - Spin to Earn Platform

A professional and realistic earning platform built with React, TypeScript, and Tailwind CSS.

## Features

### User Authentication
- **Sign Up**: Users can register with name, email, and password
- **Login**: Secure login with email and password
- **Protected Routes**: Dashboard and withdrawal pages require authentication

### Dashboard & Earning
- **Spinning Animation**: Professional spinning wheel animation
- **Instant Balance**: Users automatically see ₦59,932 balance after login
- **Real-time Notifications**: System notifications for all actions
- **Responsive Design**: Works perfectly on all devices

### Withdrawal System
- **Minimum Withdrawal**: ₦50,000 minimum withdrawal limit
- **Bank Selection**: Complete list of Nigerian banks including fintech options
- **Bank Details**: Collects bank name, account number, and account name
- **Smart Calculation**: Activation fee calculated based on withdrawal amount

### Activation Fee System
- **Transparent Pricing**: For ₦50,000 withdrawal, activation fee is ₦9,090
- **Proportional Fees**: Fee scales proportionally with withdrawal amount
- **Payment Details**: 
  - Account Number: 9164125245
  - Account Name: Abdulhamid Imam SADIQ
  - Bank: PalmPay (Business Account)
- **Screenshot Upload**: Users must upload payment proof
- **Important Warnings**: Clear instructions about exact payment amounts

### Admin Dashboard
- **Hidden Access**: 7 clicks on app logo reveals admin login
- **Secure Login**: Password: `abdul0147`
- **Request Management**: View all withdrawal requests
- **User Details**: See user name, email, bank details, and screenshots
- **Action Buttons**: Accept or reject requests with one click
- **Auto Notifications**: Users automatically notified of decisions

### Notification System
- **Success Messages**: "Congratulations you have been credited successfully thank you for trusting quick pay pro"
- **Rejection Messages**: "Sorry your withdrawal request has been rejected"
- **Real-time Updates**: Notifications appear instantly
- **Read/Unread Tracking**: Visual indicators for new notifications

## Technical Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **Routing**: React Router v6
- **Icons**: Lucide React
- **State Management**: React Context API with localStorage persistence
- **Build Tool**: Vite

## Installation & Running

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

## Application Flow

1. **Registration**: New users sign up with name, email, and password
2. **Login**: Returning users access their dashboard
3. **Dashboard**: Users see their ₦59,932 balance with spinning animation
4. **Withdrawal**: Click "Withdraw Funds" to open withdrawal modal
5. **Amount Entry**: Enter amount (minimum ₦50,000)
6. **Bank Details**: Select bank and enter account details
7. **Activation Fee**: View calculated activation fee and payment instructions
8. **Payment**: Pay exact activation fee to PalmPay business account
9. **Screenshot**: Upload payment proof
10. **Submission**: Submit withdrawal request for admin review
11. **Admin Review**: Admin reviews requests in hidden dashboard
12. **Notification**: User receives approval/rejection notification

## Security Features

- Password validation (minimum 6 characters)
- Protected routes for authenticated users only
- Secure admin access with password protection
- Local storage encryption for sensitive data
- Input validation on all forms

## Design Highlights

- **Professional UI**: Clean, modern interface with gradient backgrounds
- **Responsive**: Mobile-first design that works on all screen sizes
- **Animations**: Smooth transitions and spinning effects
- **Color Scheme**: Professional blue and green gradients
- **Typography**: Clear, readable fonts with proper hierarchy
- **Icons**: Consistent iconography throughout the application

## Bank List

The platform includes all major Nigerian banks:
- Traditional banks (Access, GTB, UBA, Zenith, etc.)
- Digital banks (Kuda, Moniepoint)
- Fintech platforms (PalmPay, Opay)

## Important Notes

- This is a demonstration platform for earning/spinning applications
- All financial transactions are simulated
- Activation fees are part of the platform model
- Users should understand the terms before using

## Support

For technical support or questions about the platform, please refer to the documentation or contact the development team.
