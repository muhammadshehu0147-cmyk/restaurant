import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, WithdrawalRequest, Notification } from '../types';

interface AuthContextType {
  currentUser: User | null;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  updateUserBalance: (amount: number) => void;
  withdrawalRequests: WithdrawalRequest[];
  addWithdrawalRequest: (request: WithdrawalRequest) => void;
  updateWithdrawalRequest: (id: string, status: 'approved' | 'rejected') => void;
  notifications: Notification[];
  addNotification: (userId: string, message: string, type: 'success' | 'error') => void;
  markNotificationAsRead: (id: string) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    const savedRequests = localStorage.getItem('withdrawalRequests');
    const savedNotifications = localStorage.getItem('notifications');
    
    if (savedUser) setCurrentUser(JSON.parse(savedUser));
    if (savedRequests) setWithdrawalRequests(JSON.parse(savedRequests));
    if (savedNotifications) setNotifications(JSON.parse(savedNotifications));
  }, []);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('withdrawalRequests', JSON.stringify(withdrawalRequests));
  }, [withdrawalRequests]);

  useEffect(() => {
    localStorage.setItem('notifications', JSON.stringify(notifications));
  }, [notifications]);

  const login = (email: string, password: string) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find((u: User) => u.email === email && u.password === password);
    
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const signup = (name: string, email: string, password: string) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    if (users.find((u: User) => u.email === email)) {
      return false;
    }
    
    const newUser: User = {
      id: Date.now().toString(),
      name,
      email,
      password,
      balance: 59932
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    setCurrentUser(newUser);
    return true;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const updateUserBalance = (amount: number) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, balance: amount };
      setCurrentUser(updatedUser);
      
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const updatedUsers = users.map((u: User) => 
        u.id === currentUser.id ? updatedUser : u
      );
      localStorage.setItem('users', JSON.stringify(updatedUsers));
    }
  };

  const addWithdrawalRequest = (request: WithdrawalRequest) => {
    setWithdrawalRequests(prev => [...prev, request]);
  };

  const updateWithdrawalRequest = (id: string, status: 'approved' | 'rejected') => {
    setWithdrawalRequests(prev => {
      const updated = prev.map(req => 
        req.id === id ? { ...req, status } : req
      );
      
      const request = prev.find(req => req.id === id);
      if (request) {
        const message = status === 'approved' 
          ? 'Congratulations you have been credited successfully thank you for trusting quick pay pro'
          : 'Sorry your withdrawal request has been rejected';
        addNotification(request.userId, message, status === 'approved' ? 'success' : 'error');
      }
      
      return updated;
    });
  };

  const addNotification = (userId: string, message: string, type: 'success' | 'error') => {
    const notification: Notification = {
      id: Date.now().toString(),
      userId,
      message,
      type,
      timestamp: new Date(),
      read: false
    };
    setNotifications(prev => [notification, ...prev]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      login,
      signup,
      logout,
      updateUserBalance,
      withdrawalRequests,
      addWithdrawalRequest,
      updateWithdrawalRequest,
      notifications,
      addNotification,
      markNotificationAsRead
    }}>
      {children}
    </AuthContext.Provider>
  );
};