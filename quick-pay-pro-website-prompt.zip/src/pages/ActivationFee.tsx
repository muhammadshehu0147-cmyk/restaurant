import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { AlertCircle, Upload, ArrowRight, X } from 'lucide-react';

export const ActivationFee: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, addWithdrawalRequest } = useAuth();
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { amount, bankName, accountNumber, accountName, activationFee } = location.state || {};

  if (!amount || !bankName || !accountNumber || !accountName) {
    navigate('/dashboard');
    return null;
  }

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('File size must be less than 5MB');
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!screenshot) {
      setError('Please upload payment screenshot');
      return;
    }

    setLoading(true);
    
    const request = {
      id: Date.now().toString(),
      userId: currentUser?.id!,
      userName: currentUser?.name!,
      userEmail: currentUser?.email!,
      amount,
      bankName,
      accountNumber,
      accountName,
      screenshot,
      status: 'pending' as const,
      timestamp: new Date(),
      activationFee
    };

    addWithdrawalRequest(request);
    
    setTimeout(() => {
      setLoading(false);
      navigate('/dashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 px-8 py-6">
            <h1 className="text-2xl font-bold text-white flex items-center">
              <AlertCircle className="mr-3 h-6 w-6" />
              Activation Fee Required
            </h1>
          </div>

          <div className="p-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                {error}
              </div>
            )}

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8">
              <h3 className="text-lg font-semibold text-blue-900 mb-4">Withdrawal Details</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-700">Withdrawal Amount:</span>
                  <span className="font-semibold text-gray-900">₦{amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-700">Activation Fee:</span>
                  <span className="font-semibold text-red-600">₦{activationFee.toLocaleString()}</span>
                </div>
                <div className="border-t pt-3">
                  <div className="flex justify-between">
                    <span className="text-gray-700">Bank Name:</span>
                    <span className="font-semibold text-gray-900">{bankName}</span>
                  </div>
                  <div className="flex justify-between mt-2">
                    <span className="text-gray-700">Account Number:</span>
                    <span className="font-semibold text-gray-900">{accountNumber}</span>
                  </div>
                  <div className="flex justify-between mt-2">
                    <span className="text-gray-700">Account Name:</span>
                    <span className="font-semibold text-gray-900">{accountName}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 border-2 border-yellow-300 rounded-xl p-6 mb-8">
              <h3 className="text-lg font-semibold text-yellow-900 mb-4">Payment Instructions</h3>
              <p className="text-yellow-800 mb-4">
                Pay the exact activation fee shown above to be eligible for your withdrawal. 
                Any mistake or failure will not be believable for the withdrawal.
              </p>
              
              <div className="bg-white rounded-lg p-4 border-2 border-yellow-400">
                <h4 className="font-semibold text-gray-900 mb-3">Send Activation Fee To:</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-600">Account Number:</span>
                  </div>
                  <div className="font-semibold text-gray-900">9164125245</div>
                  
                  <div>
                    <span className="text-gray-600">Account Name:</span>
                  </div>
                  <div className="font-semibold text-gray-900">Abdulhamid Imam SADIQ</div>
                  
                  <div>
                    <span className="text-gray-600">Bank:</span>
                  </div>
                  <div className="font-semibold text-gray-900">PalmPay</div>
                  
                  <div>
                    <span className="text-gray-600">Account Type:</span>
                  </div>
                  <div className="font-semibold text-gray-900">Business Account</div>
                </div>
              </div>

              <div className="mt-4 bg-red-100 border border-red-300 rounded-lg p-3">
                <p className="text-red-800 text-sm font-semibold">
                  ⚠️ Important: Pay the exact amount of ₦{activationFee.toLocaleString()} only!
                </p>
              </div>
            </div>

            <div className="mb-8">
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Upload Payment Screenshot
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-blue-500 transition">
                {screenshot ? (
                  <div className="relative">
                    <img src={screenshot} alt="Payment Screenshot" className="max-h-64 mx-auto rounded-lg" />
                    <button
                      onClick={() => setScreenshot(null)}
                      className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ) : (
                  <div>
                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">Click to upload or drag and drop</p>
                    <p className="text-sm text-gray-500">PNG, JPG up to 5MB</p>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleScreenshotUpload}
                      className="mt-4"
                    />
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading || !screenshot}
              className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-4 rounded-xl font-semibold text-lg hover:from-green-700 hover:to-green-800 transition transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
              ) : (
                <>
                  Submit Withdrawal Request
                  <ArrowRight className="ml-2 h-5 w-5" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};