export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  balance: number;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  amount: number;
  bankName: string;
  accountNumber: string;
  accountName: string;
  screenshot: string;
  status: 'pending' | 'approved' | 'rejected';
  timestamp: Date;
  activationFee: number;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  type: 'success' | 'error';
  timestamp: Date;
  read: boolean;
}

export const NIGERIAN_BANKS = [
  "Access Bank",
  "Citibank",
  "Ecobank Nigeria",
  "Fidelity Bank",
  "First Bank of Nigeria",
  "First City Monument Bank (FCMB)",
  "Globus Bank",
  "Guaranty Trust Bank (GTB)",
  "Heritage Bank",
  "Jaiz Bank",
  "Keystone Bank",
  "Parallex Bank",
  "Polaris Bank",
  "Premium Trust Bank",
  "Providus Bank",
  "Signature Bank",
  "Stanbic IBTC Bank",
  "Standard Chartered Bank",
  "Sterling Bank",
  "SunTrust Bank",
  "Titan Trust Bank",
  "Union Bank of Nigeria",
  "United Bank for Africa (UBA)",
  "Unity Bank",
  "Wema Bank",
  "Zenith Bank",
  "PalmPay",
  "Opay",
  "Kuda Bank",
  "Moniepoint"
];

export const ADMIN_PASSWORD = "abdul0147";
export const MIN_WITHDRAWAL = 50000;
export const BASE_ACTIVATION_RATE = 9090 / 50000; // 0.1818
export const INITIAL_BALANCE = 59932;